var TestScript = pc.createScript('testScript');

// initialize code called once per entity
TestScript.prototype.initialize = function() {

};

// update code called every frame
TestScript.prototype.update = function(dt) {

};

// uncomment the swap method to enable hot-reloading for this script
// update the method body to copy state from the old instance
// TestScript.prototype.swap = function(old) { };

// learn more about scripting here:
// https://developer.playcanvas.com/user-manual/scripting/